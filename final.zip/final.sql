-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2019 at 08:20 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `awards`
--

CREATE TABLE `awards` (
  `empid` varchar(10) NOT NULL,
  `awardname` varchar(255) NOT NULL,
  `date` varchar(10) NOT NULL,
  `place` varchar(255) NOT NULL,
  `awardedby` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `awards`
--

INSERT INTO `awards` (`empid`, `awardname`, `date`, `place`, `awardedby`, `description`) VALUES
('17251A05F6', 'second', '2019-04-30', 'svbjvd', 'sdhuvukh', 'sdhk'),
('17251A05F6', 'snfsdfs', '2019-01-01', 'hyd', 'aedd', 'asklfdjskgdfk'),
('51234', 'akkulu', '2019-08-14', 'Gnits', 'sb', 'akkuluuuuuu'),
('51234', 'excellency', '2019-02-01', 'Gnits', 'sb', 'asklfjk'),
('51234', 'excellency', '2019-04-03', 'kdsdfjdkh', 'kqjewkhbfjdkl', 'wekdvjvh hjkdlw'),
('51234', 'hi', '2019-08-08', 'hi', 'hi', 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `empid` varchar(10) NOT NULL,
  `title` varchar(30) NOT NULL,
  `natorinter` text NOT NULL,
  `proceedings` varchar(30) NOT NULL,
  `confname` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `ISBN` int(13) NOT NULL,
  `institute` varchar(30) NOT NULL,
  `publishername` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`empid`, `title`, `natorinter`, `proceedings`, `confname`, `date`, `ISBN`, `institute`, `publishername`) VALUES
('17251A05F6', 'adsd', 'national', 'asmdsjfmf', 'adklslf', '2018-12-01', 0, 'gnits', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `certifications`
--

CREATE TABLE `certifications` (
  `empid` varchar(10) NOT NULL,
  `course` varchar(255) NOT NULL,
  `offeredby` text NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `score` int(11) NOT NULL,
  `ctype` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `certifications`
--

INSERT INTO `certifications` (`empid`, `course`, `offeredby`, `startdate`, `enddate`, `score`, `ctype`) VALUES
('17251A05F6', 'ml', 'nptel', '2018-07-29', '2018-12-31', 70, 'elite'),
('51234', 'sdalosidkjh', 'alsdkjhgh', '2019-05-04', '2019-06-05', 80, 'merit');

-- --------------------------------------------------------

--
-- Table structure for table `consultancy`
--

CREATE TABLE `consultancy` (
  `empid` varchar(10) NOT NULL,
  `consultantname` varchar(255) NOT NULL,
  `consultancyproject` varchar(255) NOT NULL,
  `consultingagency` text NOT NULL,
  `revenue` int(20) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consultancy`
--

INSERT INTO `consultancy` (`empid`, `consultantname`, `consultancyproject`, `consultingagency`, `revenue`, `startdate`, `enddate`) VALUES
('17251A05F6', 'askfj', 'salfakf', 'adsfdsfs', 23000, '2019-01-03', '2019-02-04');

-- --------------------------------------------------------

--
-- Table structure for table `guestlectures`
--

CREATE TABLE `guestlectures` (
  `empid` varchar(10) NOT NULL,
  `topicname` varchar(30) NOT NULL,
  `areaoflecture` text NOT NULL,
  `venue` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `organisation` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guestlectures`
--

INSERT INTO `guestlectures` (`empid`, `topicname`, `areaoflecture`, `venue`, `date`, `organisation`) VALUES
('17251A05F6', 'ml for stock', 'ml', 'cbit', '2020-01-02', 'cbitskja'),
('51234', 'jbtd', 'kjkhjgtr', 'oiuyt', '2019-06-05', 'jghfh');

-- --------------------------------------------------------

--
-- Table structure for table `paperconf`
--

CREATE TABLE `paperconf` (
  `empid` varchar(10) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `confname` text NOT NULL,
  `Venue` text NOT NULL,
  `Organiser` text NOT NULL,
  `Date` date NOT NULL,
  `ISBN` int(13) NOT NULL,
  `DOI` varchar(15) NOT NULL,
  `proceededtojournal` text NOT NULL,
  `areaofspecialisation` text NOT NULL,
  `author` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paperconf`
--

INSERT INTO `paperconf` (`empid`, `Title`, `confname`, `Venue`, `Organiser`, `Date`, `ISBN`, `DOI`, `proceededtojournal`, `areaofspecialisation`, `author`) VALUES
('17251A05F6', 'IoT', 'IoT', 'GNITS', 'CSI', '2018-02-12', 12678, '234', 'yes', 'IoT', 'Akshita'),
('17251A05F6', 'ML', 'ML', 'GNITS', 'CSI', '2019-02-12', 123456, '123', 'yes', 'ML', 'Apurva');

-- --------------------------------------------------------

--
-- Table structure for table `paperjourn`
--

CREATE TABLE `paperjourn` (
  `empid` varchar(10) NOT NULL,
  `author` text NOT NULL,
  `publication_title` varchar(255) NOT NULL,
  `volume_no` int(5) NOT NULL,
  `issue_no` varchar(10) NOT NULL,
  `ISSN` int(8) NOT NULL,
  `impact_factor` int(10) NOT NULL,
  `date` date NOT NULL,
  `open_journal` text NOT NULL,
  `ugc_approved` text NOT NULL,
  `scopus_indexed` text NOT NULL,
  `web_of_science` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `empid` varchar(10) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(40) NOT NULL,
  `designation` varchar(20) NOT NULL,
  `qualifications` text NOT NULL,
  `areasofinterest` text NOT NULL,
  `phone` int(10) NOT NULL,
  `papers` text NOT NULL,
  `projects` text NOT NULL,
  `courses` text NOT NULL,
  `awards` varchar(255) NOT NULL,
  `publications` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `workshops` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`empid`, `name`, `email`, `designation`, `qualifications`, `areasofinterest`, `phone`, `papers`, `projects`, `courses`, `awards`, `publications`, `experience`, `workshops`) VALUES
('51234', 'xyz', '', '', 'afas', '', 0, 'ussf', 'akfjk', 'asndsjs', 'qwjr', 'alkfkja', '18', 'ajfdhs');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `empid` varchar(10) NOT NULL,
  `fundingagency` varchar(40) NOT NULL,
  `principalinvestigator` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `regno` int(20) NOT NULL,
  `cost` int(20) NOT NULL,
  `status` text NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`empid`, `fundingagency`, `principalinvestigator`, `title`, `regno`, `cost`, `status`, `startdate`, `enddate`) VALUES
('17251A05F6', 'ahhjdsadss', 'adsadoslifh', 'ad;fslkjhsdshjkl', 0, 263891, 'complete', '2017-05-04', '2019-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `resourceperson`
--

CREATE TABLE `resourceperson` (
  `empid` varchar(10) NOT NULL,
  `topicname` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `venue` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resourceperson`
--

INSERT INTO `resourceperson` (`empid`, `topicname`, `date`, `venue`, `description`) VALUES
('17251A05F6', 'ml for stock', '2000-03-23', 'cbit', 'alskdjfdkfsla;sskdj');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `empid` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`empid`, `password`) VALUES
('1263234672', 'hhggdgfd'),
('17251A05F6', 'test123'),
('51234', 'test123'),
('admincse', 'test123');

-- --------------------------------------------------------

--
-- Table structure for table `workshops`
--

CREATE TABLE `workshops` (
  `empid` varchar(10) NOT NULL,
  `programtitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `venue` varchar(30) NOT NULL,
  `resourceperson` text NOT NULL,
  `type` text NOT NULL,
  `trainingmethodology` text NOT NULL,
  `participants` text NOT NULL,
  `noofparticipants` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workshops`
--

INSERT INTO `workshops` (`empid`, `programtitle`, `description`, `startdate`, `enddate`, `venue`, `resourceperson`, `type`, `trainingmethodology`, `participants`, `noofparticipants`) VALUES
('17251A05F6', 'aslfdjg', 'a;ofliskgjdh', '2019-01-01', '2019-01-02', 'cbit', 'asdfsgdhgfdfsd', 'fdp', 'handson', 'kaykay,akfudsjk,kajdhfjs', 3);

-- --------------------------------------------------------

--
-- Table structure for table `workshopsorganised`
--

CREATE TABLE `workshopsorganised` (
  `empid` varchar(10) NOT NULL,
  `workshopname` varchar(255) NOT NULL,
  `venue` varchar(255) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workshopsorganised`
--

INSERT INTO `workshopsorganised` (`empid`, `workshopname`, `venue`, `startdate`, `enddate`, `role`) VALUES
('17251A05F6', 'aslfdjg', 'cbit', '2019-03-12', '2019-03-17', 'convenor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `awards`
--
ALTER TABLE `awards`
  ADD PRIMARY KEY (`empid`,`awardname`,`date`),
  ADD KEY `awardname` (`awardname`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`empid`,`title`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `certifications`
--
ALTER TABLE `certifications`
  ADD PRIMARY KEY (`empid`,`course`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `consultancy`
--
ALTER TABLE `consultancy`
  ADD PRIMARY KEY (`empid`,`consultantname`,`consultancyproject`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `guestlectures`
--
ALTER TABLE `guestlectures`
  ADD PRIMARY KEY (`empid`,`topicname`,`date`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `paperconf`
--
ALTER TABLE `paperconf`
  ADD PRIMARY KEY (`empid`,`Title`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `paperjourn`
--
ALTER TABLE `paperjourn`
  ADD PRIMARY KEY (`empid`,`publication_title`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`empid`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`empid`,`title`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `resourceperson`
--
ALTER TABLE `resourceperson`
  ADD PRIMARY KEY (`empid`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`empid`(15)),
  ADD KEY `EmpId` (`empid`);

--
-- Indexes for table `workshops`
--
ALTER TABLE `workshops`
  ADD PRIMARY KEY (`empid`,`programtitle`,`startdate`),
  ADD KEY `empid` (`empid`);

--
-- Indexes for table `workshopsorganised`
--
ALTER TABLE `workshopsorganised`
  ADD PRIMARY KEY (`empid`),
  ADD KEY `empid` (`empid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `awards`
--
ALTER TABLE `awards`
  ADD CONSTRAINT `awards_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `certifications`
--
ALTER TABLE `certifications`
  ADD CONSTRAINT `certifications_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `consultancy`
--
ALTER TABLE `consultancy`
  ADD CONSTRAINT `consultancy_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `guestlectures`
--
ALTER TABLE `guestlectures`
  ADD CONSTRAINT `guestlectures_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `paperconf`
--
ALTER TABLE `paperconf`
  ADD CONSTRAINT `paperconf_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `paperjourn`
--
ALTER TABLE `paperjourn`
  ADD CONSTRAINT `paperjourn_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `resourceperson`
--
ALTER TABLE `resourceperson`
  ADD CONSTRAINT `resourceperson_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `workshops`
--
ALTER TABLE `workshops`
  ADD CONSTRAINT `workshops_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `workshopsorganised`
--
ALTER TABLE `workshopsorganised`
  ADD CONSTRAINT `workshopsorganised_ibfk_1` FOREIGN KEY (`empid`) REFERENCES `usertable` (`EmpId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
