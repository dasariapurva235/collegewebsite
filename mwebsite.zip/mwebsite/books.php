<html>
 <head>
<link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  

 </head>
 <body>
  <?php include "header.php" ?>
  <div class="container">
  <br>
  <div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="loggedin.php">Home</a></li>
  <li><a href="#">Publications</a></li>
  <li><a href="#">Books</a></li>
  <li><a href="books.php">Update</a></li>
</ul>
</div>
<div class="sidebar">

<h3> CSE</h3>
<ul>
<li><a href="#">Publications</a></li>
    <ul>
      <li><a href="#">Books</a></li>
      <li><a href="#">Journals</a></li>
 <li><a href="#">Consultancy Papers</a></li>
    </ul>
<li><a href="#">Projects</a></li>
    <ul>
      <li><a href="#">Research</a></li>
 <li><a href="#">Consultancy</a></li>
    </ul>
<li><a href="#">Workshops</a></li>
    <ul>
      <li><a href="#">Organized</a></li>
 <li><a href="#">Attended</a></li>
    </ul>
<li><a href="#">Recognitions</a></li>
    <ul>
      <li><a href="#">Certifications</a></li>
 <li><a href="#">Awards</a></li>
 <li><a href="#">Resource person</a></li>
 <li><a href="#">Special Chair</a></li>
    </ul>
<li><a href="#">Guest Lectures</a></li>

</div>	
<div class="content1">


  <form action="booksReg.php" method="post" enctype="multipart/form-data">
  Title of the Book or chapter published:<br>
  <input type="text" name="title" id="title"><br><br>
  <input type="radio" name="natorinter" id="natorinter" value="national">National<br>
  <input type="radio" name="natorinter" id="natorinter" value="international">International<br>
  Title of the Paper:<br>
  <input type="text" name="paper" id="paper"><br>
  Title of the Proceedings of the conference:<br>
  <input type="text" name="proceedings" id="proceedings"><br>
  Name of the Conference:<br>
  <input type="text" name="confname" id="confname"><br>
  Date Published:<br>
  <input type="date" name="date" id="date"><br>
  ISBN/ISSN Number:<br>
  <input type="text" name="isbn" id="isb"><br>
  Affiliating Institute at the time of publication:<br>
  <input type="text" name="institute" id="institute"><br>
  Name of the publisher:<br>
  <input type="text" name="publishername" id="publishername"><br><br>
  <input type="submit" value="Submit"><br>
  </form>
  </div>
</div>  
 </body>
</html>