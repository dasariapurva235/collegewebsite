<?php

session_start(); 
header('location:books.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username']; 
$title= $_POST['title'];
$natorinter= $_POST['natorinter'];
$proceedings= $_POST['proceedings'];
$confname= $_POST['confname'];
$date = $_POST['date'];
$isbn= $_POST['isbn'];
$institute = $_POST['institute'];
$publishername=$_POST['publishername'];

$stmt = $dbh->prepare("insert into books values(?,?,?,?,?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$title);
$stmt->bindParam(3,$natorinter);
$stmt->bindParam(4,$proceedings);
$stmt->bindParam(5,$confname);
$stmt->bindParam(6,$date);
$stmt->bindParam(7,$isbn);
$stmt->bindParam(8,$institute);
$stmt->bindParam(9,$publishername);
$stmt->execute();


echo "Success";

?>
