<?php

session_start(); 
header('location:certification.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username']; 
$course= $_POST['course'];
$offeredby=$_POST['offeredby'];
$startdate= $_POST['startdate'];
$enddate= $_POST['enddate'];
$score = $_POST['score'];
$ctype= $_POST['ctype'];


$stmt = $dbh->prepare("insert into certifications values(?,?,?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$course);
$stmt->bindParam(3,$offeredby);
$stmt->bindParam(4,$startdate);
$stmt->bindParam(5,$enddate);
$stmt->bindParam(6,$score);
$stmt->bindParam(7,$ctype);
$stmt->execute();

//$target_dir = "certifications/". $empid; 
$target_dir = "certifications/". $empid."/";													//this is because empid has the folder name
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    
if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
{
 echo "The file ". basename( $_FILES['file']['name']). " is uploaded";
 }
 else {
 echo "Problem uploading file";
 }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

echo "Success";

?>
