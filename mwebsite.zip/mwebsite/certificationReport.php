<?php

if(isset($_POST['search']))
{
	echo 'filter';
    $startdate= $_POST['startdate'];
	 $enddate = $_POST['enddate'];
    // search in all table columns
    // using concat mysql function
	$query = "SELECT `empid`,`course`,`score` FROM `certifications` WHERE `date` >= '".$startdate."' AND `date` <= '".$enddate."'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT `empid`,`course`,`score` FROM `certifications` WHERE MONTH(date) = MONTH(current_date())";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "final");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html>
<html>
    <head>
	<link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <style>
            {
            table,tr,th,td
                border: 1px solid black;
            }
        </style>
    </head>
    <body>
        <?php include "header2.php" ?>
        <div class="container">
  <br>
  <div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="loggedin2.php">Home</a></li>
  <li><a href="#">Recognitions</a></li>
  <li><a href="#">Certifications</a></li>
  <li><a href="certificationReport.php">Reports</a></li>
</ul>
</div>
 <div class="sidebar">

<h3> CSE</h3>
<ul>
<li><a href="#">Publications</a></li>
<li><a href="#">Projects</a></li>
<li><a href="#">Workshops</a></li>
<li><a href="#">Recognitions</a></li>
<li><a href="#">Guest Lectures</a></li>

</div>
<div class="content1">
        <form action="" method="post">
            <input type="date" name="startdate" placeholder="Value To Search"><br><br>
			<input type="date" name="enddate" placeholder="Value To Search"><br><br>
            <input type="submit" name="search" value="Filter"><br><br>
            
            <table>
                <tr>
                    <th>empid</th>
                    <th>course</th>
					<th>score</th>
                </tr>

      <!-- populate table from mysql database -->
	   <?php error_reporting(E_ERROR | E_PARSE); ?>
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['empid'];?></td>
                    <td><?php echo $row['course'];?></td>
					<td><?php echo $row['score'];?></td?
                </tr>
                <?php endwhile;?>
            </table>
        </form>
        </div>
    </body>
</html>

