<?php

session_start(); 
header('location:consultancy.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username']; 
$consultantname= $_POST['consultantname'];
$consultancyproject= $_POST['consultancyproject'];
$consultingagency= $_POST['consultingagency'];
$revenue=$_POST['revenue'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];

$stmt = $dbh->prepare("insert into consultancy values(?,?,?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$consultantname);
$stmt->bindParam(3,$consultancyproject);
$stmt->bindParam(4,$consultingagency);
$stmt->bindParam(5,$revenue);
$stmt->bindParam(6,$startdate);
$stmt->bindParam(7,$enddate);
$stmt->execute();

echo "Success";

?>
