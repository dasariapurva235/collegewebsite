<?php

session_start();


$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"final");
$name = $_POST['id'];


$sql = "DELETE FROM usertable WHERE EmpId = ".$name;

$result = mysqli_query($con,$sql);
if($con->query($sql) === TRUE)
echo "DELETE SUCCESSFUL";
else
echo "UNSUCCESSFUL";
$con->close();

?>
