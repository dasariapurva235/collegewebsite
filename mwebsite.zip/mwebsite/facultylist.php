<html>
<body>
<?php 
$username = "root"; 
$password = ""; 
$database = "final"; 
$mysqli = new mysqli("localhost", $username, $password, $database); 
$query = "SELECT * FROM faculty_list";
 
 
echo '<table border="3" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Faculty Name</font> </td> 
          <td> <font face="Arial">Department</font> </td> 
       </tr>';
 
if ($result = $mysqli->query($query)) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["faculty_name"];
        $field2name = $row["department"];
        
        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
             </tr>';
    }
    $result->free();
} 
?>
</body>
</html>