<!DOCTYPE html> 
<html>
<head>
    <title>Staff Information</title>
	<link rel="stylesheet" type="text/css" href="styles5.css">
</head>
<body>
   <center>
        <h1>Staff information</h1>
    </center>
    <div class="faclist">
    <table border="2" bordercolor="black" align="center">
        <tr>
		<td>
		Name              : Dr.M.Seetha <br>
        Designation       : Professor & HOD <br>
        Qualification     : Ph.D.<br>
        Experience        : 25 years<br>
        Areas of Interest : Image Processing,DM,AI,Soft Computing<br>
       E-mail             : maddala.seetha@gnits.ac.in<br>
       Phone No.	      : 040-23565648 Extn - 305<br>
	   </td>
	   <td>
	   <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIEArAMBEQACEQEDEQH/xAAbAAEAAwEBAQEAAAAAAAAAAAAAAwQFBgIBB//EADsQAAICAQIDBQUGBAUFAAAAAAECAAMRBBIFITETQVFhcQYUIjKRQoGxwdHwFSOh4TM1UnPxBzRDU4L/xAAbAQEAAwEBAQEAAAAAAAAAAAAAAQIDBAYFB//EAC4RAAICAQMDAgMIAwAAAAAAAAABAhEDBCExBRJBIlETMmEGFHGRobHB8IHR4f/aAAwDAQACEQMRAD8A/M5ByiAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAM8s90A+bh4wLPaqzttRSzHoAMmHsWhCU5KMVbPV1VlFpquQpYvVTFlsmHJim4TjT9iPMGYgCAIAgCAIAgCAIAgCAOZMEpWdXwT2Kv4rp7S2tpovAylYU2geVhX5D9fOVcvY6XpMsVclRzvEtBq+F62zR6+k1X143KTkEHoQRyIPiJMWmrRzNNOmVpJAgGjwbhb8Subd2iadAd9iqOo7h5yJSo+l07p8tZOuIrz/BoXezopvrsov7SgMC6uMHHl45lHk2Psx+zso6iDjK4XvfJ0VC0bSb9PU4u5MWUc8dPzlE3R6DLosEpNqKso2aDR6TWm3TUqjFcMB8vqB3SJyfBXRdMwYMjzQjTZL2VfvBv2ZsK4JHgJCs6JafFGUs3b6mqMTScFpet7NWzK7AsFU4Cd80eTejzuD7PReJ5c7pvevYwnrdAC6MobmpKkBh4iap2eTljlD5lX8nmCggCAIAgCAIAgCAIBpez+nr1PFqEvz2YOW/47/SVk6R3dPgpZrfC3P33gWv01GgRdDq0tCoMVFFTd5jE+a9Wu1uLp+zNsnqlbON9utDR7SWaW1GoFlAbJuvWkkHopZvMd2ek4+mZs0pSSfPucGb5qR+bce4VquF2VpqdJVUr5KW03dqlnjhgSOX15z7sE+W7My37O1aJtO7X0I9gswWbngYEpkm4uj1fQdHp8+CU5xTldb/AIG9o9PTpy/uqipCd5A6Z6H06CUu3Z6HBpMWli4440m7GqO1GA6H8JDOvHuR0XM1fZ7uQziTF+CzirsiWwm3ceuZHk0fy0SPb8eF6tylrohLY9EKFOQMdOYkNFXFS2ZV4jpa+IUJXY7AK+4bcdcEd8mMu0+d1DpsNbFQk6rfYwOL8Nr4f2PZ3m3tM5UjBGP2JrCfceN6r0taBxqV3+ZnS58cQBAEAQBAEAQBBJ0PsvToLBZ71ddVfkGs14xy7jn8py6nI4Li0fT0coww9yVt8nXVWLptMzUa2rtB0BG3n6fpPh5mpy4K5pporcE4vS99t19Fj31OQ7Vtgq2cfQ4nXDHLTpbbfqfNlbZg+3Gu0Ou45RbXSqoEAvZVC2Pz+1jw54759PBNzj3bmmPs74/E+W9z3XwzT1Ys0V7orAE1sNwbzB6/jIlJSW/J7zR9Neln8TTy9L8P/ZY0rtTcFsIKMMAjpM1sz7LujzrbTXy6oeQ8vKWkyy2IQzVqrnkGJx58pCCas+V2jdubopyfWTZZs9ixQxdue7mBmTYvwetz2HmR6Zhuy2yPSWqOSgmVIZn8Q4XdrNS1o1VSqRhFYHkJtGcYqjyXUujavV6h5O5V4Rg3VtTc9T/Mh2nE2uzyWXHLFN45co8QZiAIAgCAIAgCCSbTal9MxNYUhuTKwyDKTxqaploZJQdxLq8b1NaFaFWskdQBn64zOb7lBu5Oy8s0pLcp6XUvTaX3N8XzbWxmdE8aa/ApCVS3NvRU6FKd4pSxm6s43EeXPpOeWSVnuendP0TwKaim3ze5aF4AwmNo6Adw8Jl3H3IpRVLg9Kq2ndUTvHM156+k0RN0Q6i3euOu7lz/AH1hlpcHjUso0q0lslenriGykuCtWLbNOroucHmO/wDfSRRW3VngWPY5ZVYheuB0jcr8S3ZLTqlJ5/L5csyUzSOWy9VbWw+FAPvk2aJlhVaysgWms/ZIXdiSq8mWeE5Qag6b8nN8W4c+iK2NcLlsJwxGGz35nRCSlwfn3Vem5NHNSnLu7vJny58kQBAEAQBAEAQBAEAY5wSk26Rq6Oq9EANdgPjynDNXLZnuekxyYdOoPG0/79S7XpdRa2MbD15+Ep2n2od8uVRDez6e0ANll7xJ43LvYu6XU0Xl7HqrewjDbiQQfETSLXkq6lunVFPW14s7SknaPst3frIkvYrN+UVX1N64NDb0HN8qCB6yFZw5NXNyqHH6FnS33Cse61KzfaA/riWjfg3+K+1dqskxp9RUxO3T21MFsUr1B7/Ln4SWk17FoZIvg+leyA2tXYD0ZGz/AElGqOmMi5R2mAdxURZpuzK9o9TRc9NVQzZVne3r3f0nThW1nh/tFqMOXNGMHbjd/wB9zHHSannRBAgCAIAgCAIAgCAeq3NdiuoBKnIzIlG1Rtp80sGSOSK3W5u08STs02Ood+veQZxOEotnv9P1XTZIx9at+PqWhqK004/nbtx+PErsfSUl5IbbtLYu2u7ZjxQy23gnvi+DOdMb7K9QGVPmKg8vqJFHLPltPg9rrbU4cbaXr7SmzGHQncDzHl4/SaLg456icYScN2ijXqLxq7HYrVYx3bcePn4Q0cmDUZO+Sltfgv1WbBvGE281etsgN18cj0ko2nNpcUU31R7c5s2nPzJzx34PM/v1kyWxx4NQ/i03Ro6fUtYcndYp6YABEytnoMM7Vrc0FNtY3IG2d+4dIdnS7MTjKp74bUsVjb8TKO4zqxSco7o/P+uYMWPVOWOV927+jM+aHxRAEAQBAEAQBAEAQBBJ7pVzYOz+Yc8+EpkaUbZ16HFlyaiPweVuXbGrPeQe+cB79STW/JcArp4UpwGexifu6S1bG0Go4yOugjhe8KSWtY/QAD9+cmtiuOPob8lVkGm0tpa1P564ZN2W+4eOPHxlonBmSxYpW95Eq2M+jTRX6VbbVB7Fs8yAOQml2ZSm1jWGUbdbFGhGNRJevkOY3fEfLpK8GGLHKULf7k2l03bABbMsDkqOp/WQ9zfBp4trcvV1hU5hgB3rKH2IKkWm7avRvbpyXIHy5MtjVy5ObqGTLj0s54o2znBO0/NhBAgCAIAgCAIAgCAIAgE1Fy1qwYH4upExy43Pg+x0vqGLSdyyR58nwsbGIHTvzymTwqMbkzvXVMmpyrHgjt7/AELtFrXe66TaqjdzbvIzmZXZ6GEn6YFhluqvNWntYFhusA6Y7vvhbHRkT76i/wASidIHsd7HCqFzuPn/AGkp+Ding7pOb9jy1l3vaazTkqysVrDDO0dJfuo5nhnOSyp7lmvUe9MpNa06mv5nTlvkNnXifxHuqkiwfirtAGbUbdgjBB65U/lIvY27Hv8AQsaK5CM2I+8HJ2nr9YTR1wex84hr6tIFOnRja/QkYXH5zSEO/c+R1fqq0SUYL1P8vxOdPM55c/CdR4Fu22xBAgCAIAgCAIAgCAIAgFvhuhs4hqRVXkAc2bHJR+slKw9jd12h4fpdGQi/4fUt9pj4nv8AHEzzQTV+x9HpeocMqitk+X9DCrvFWpV6sOwzgnoJyODirZ6iGvxZdQseLdre/BLXdcunexGy1wIL945yl0fQj3PG2vJc7OtuF02cgAmPUgYlmtjpx9rwr6EXCVr7GxXHMvuHr4QjLTKotP3HYGuxdRVtsXo3n4yGy8caUu+JaF1KlrlcCxBzDjn98kmWXHGDk3VcktLaZrVam+oqT/rGceElwd8FIa3TSSayJ/5M7jrVhkpRiWQ56dAQP7TbDFqzzH2j1GHJKOODtxv9jKnQeYEAQBAEAQBAEAQBAEAQDT4FrDRbZUW2rcBk455HcJKdBlbiV73ap1cnajEKM8vWVQoh04y45HHMHAz3TLNFyWx9bpWpw6eblkdWSJ23ZPSGYIv2emPGcjZ6rFJzh6X6WT6C2qncl7BUYZDEZGY5N8GWGO1LgkuXsNV2bqVqatenUAjqfzktUZ6fVw1Fzh8vH/S7pEfT1/Eoah2OCOY9QZF0d+OaW0XZon2d11lVesprWxL0D7UPxAeBB7jLfDnXckfMydR0bzzw5JU1t9DktXp302pt09q7XrcqQfIzuTPBZIxU2o8WyMDAxJIEECAIAgCAIAgCAIAgCAIA6cwcEdDANXh2g963ajU5ZW+UZwW8zIFmv2dVKYqrVB/pUYkpDuK9unYVWXLpkIcYJ6E+Uwmoq9jf71mcFBydIxRfhU0zacK4tHxEfN6/WQkq4NsmszZH3Sl4Ny67QXGqlaWqsUfZXIIx45kTxpltB1HLo5trdPlM6ThPuf8AD6dEiF0AydyjvznpnlzIl4QjSiyufqGXJnlli+2yb2l0nF9ToaP4JcESlcNWnwswA5bT5eE27a4OOUnNuUnbZ+ba63VW6p/fmZr6/wCW27qMcsH0ggggCAIAgCAIAgCAIAgCAIAgCAdTwupl4fRy5bMgZ8ecUQy0cLz2jlz5yKI2IrXZyLC+Tj5QeQ8sSEqIZi3aSvTa2tycsXDg/fzEzumXUiRQFsZ+Wc5UjoRKynRVm/wixqq2tbcucdH2nHpJg6RSyDj3tJjTmjR2Htm5F1sPwflmap2WRyBJZiWOSepPUyxc+QBAEAQBAEAQBAEAQBAEAQBBJ2XCSP4RpnYfY5k+RI/CWozb3M/WcSa0MuhrLn/2tyT7vGVbJSrkztK2rpuY5W3ecspbqfHMq2g2jVvqruGlRqLRawzs29fEAzizy7HZTjgzezZTUtlisFA5DyEmPqdkt+xs6G8WhUtIZFHy4mq5Ktluz2c4drB8Ctp3PPdX4+YM3iWUjlOL8Ot4Xrn01p3AYKOBgMD3iWNEUoAgCAIAgCAIAgCAIAgCAIAMEnZ6D/IdL/tD8ZfwZPkyv/AvoPwmZDPFX+KJRklvW/5tov8AaP5zk1PkeGZi9Pr+Mrj5Kmjw/wCdZuuSGdVw/u9J0IIx/wDqL/2vDP8A6msuEbR4OJlCRAEAQBAEAQD/2Q==" alt="">
	   </td>
	   </tr>
	   <tr>
	   	<td>
		Name              : Dr. K. Venugopal Rao <br>
		Designation       : Professor <br>
        Qualification     : Ph.D.<br>
        Experience        : 27 years<br>
        Areas of Interest : AI, SE, NN, CN, OS<br>
       E-mail             : kvgrao1234@gmail.com <br>
       Phone No.	      : 040-23565648<br>
	   </td>
	   <td>
	   <img src="" alt="K VENUGOPAL RAO">
	   </td>
	</table>
	</div>
</body>
<html>