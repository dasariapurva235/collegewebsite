<!DOCTYPE html>
<head>
 <link rel="stylesheet" type="text/css" href="style5.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
<body>
<div class="container">
<center><img src="profile.png"></center>
<br>
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
  <ul class="nav">
    <li><a href="#">Publications</a>
      <ul>
        <li><a href="#">Books</a>
		   <ul>
            <li><a href="seeb.php">Show</a></li>
            <li><a href="books.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Journals</a>
		  <ul>
            <li><a href="seepj.php">Show</a></li>
            <li><a href="paperjourn.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Conference Papers</a>
		  <ul>
            <li><a href="seepc.php">Show</a></li>
            <li><a href="paperConf.php">Update</a></li>
          </ul>
		</li>
      </ul>
    </li>
    <li><a href="#">Projects</a>
      <ul>
        <li><a href="#">Research</a>
		<ul>
            <li><a href="seer.php">Show</a></li>
            <li><a href="research.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Consultancy</a>
          <ul>
            <li><a href="seeco.php">Show</a></li>
            <li><a href="consultancy.php">Update</a></li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="#">Workshops</a>
	   <ul>
        <li><a href="#">Organized</a>
		<ul>
            <li><a href="seew.php">Show</a></li>
            <li><a href="workshopsorganised.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Attended</a>
		<ul>
            <li><a href="seewo.php">Show</a></li>
            <li><a href="workshops.php">Update</a></li>
          </ul>
		</li>
        
      </ul>
	</li>
    <li><a href="#">Recognitions</a>
      <ul>
        <li><a href="#">Certifications</a>
		<ul>
            <li><a href="seec.php">Show</a></li>
            <li><a href="certification.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Awards</a>
		<ul>
            <li><a href="seea.php">Show</a></li>
            <li><a href="awards.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Resource person</a>
		<ul>
            <li><a href="seerp.php">Show</a></li>
            <li><a href="resourceperson.php">Update</a></li>
          </ul>
		</li>
        <li><a href="#">Special Chair</a>
		<ul>
            <li><a href="#">Show</a></li>
            <li><a href="#">Update</a></li>
          </ul>
		</li>
      </ul>
    </li>
	<li><a href="#">GuestLectures</a>
      <ul>
            <li><a href="seeg.php">Show</a></li>
            <li><a href="guestlectures.php">Update</a></li>
          </ul>
		</li>
    <li><a href="logout.php">LogOut</a></li>
	</ul>
</nav>

</div>
</html>