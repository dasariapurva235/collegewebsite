<!DOCTYPE html>
<head>
 <link rel="stylesheet" type="text/css" href="style5.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
<body>
<div class="container">
<center><img src="profile.png"></center>
<br>
<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
  <ul class="nav">
    <li><a href="#">Publications</a>
      <ul>
        <li><a href="#">Books</a>
		   <ul>
            <li><a href="seeb2.php">Show</a></li>
            <li><a href="booksReport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Journals</a>
		  <ul>
            <li><a href="seepj2.php">Show</a></li>
            <li><a href="paperjournReport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Conferences</a>
		  <ul>
            <li><a href="seepc2.php">Show</a></li>
            <li><a href="paperconfReport.php">Reports</a></li>
          </ul>
		</li>
      </ul>
    </li>
    <li><a href="#">Projects</a>
      <ul>
        <li><a href="#">Research</a>
		<ul>
            <li><a href="seer2.php">Show</a></li>
            <li><a href="researchReport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Consultancy</a>
          <ul>
            <li><a href="seeco2.php">Show</a></li>
            <li><a href="consultancyReport.php">Reports</a></li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="#">Workshops</a>
	   <ul>
        <li><a href="#">Organized</a>
		<ul>
            <li><a href="seew2.php">Show</a></li>
            <li><a href="workshopsorganisedReport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Attended</a>
		<ul>
            <li><a href="seewo2.php">Show</a></li>
            <li><a href="workshopsReport.php">Reports</a></li>
          </ul>
		</li>
        
      </ul>
	</li>
    <li><a href="#">Recognitions</a>
      <ul>
        <li><a href="#">Certifications</a>
		<ul>
            <li><a href="seec2.php">Show</a></li>
            <li><a href="certificationReport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Awards</a>
		<ul>
            <li><a href="seea2.php">Show</a></li>
            <li><a href="awardsreport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Resource person</a>
		<ul>
            <li><a href="seerp2.php">Show</a></li>
            <li><a href="resourcepersonReport.php">Reports</a></li>
          </ul>
		</li>
        <li><a href="#">Special Chair</a>
		<ul>
            <li><a href="#">Show</a></li>
            <li><a href="#">Reports</a></li>
          </ul>
		</li>
      </ul>
    </li>
	<li><a href="#">GuestLectures</a>
      <ul>
            <li><a href="seeg2.php">Show</a></li>
            <li><a href="guestlecturesReport.php">Reports</a></li>
          </ul>
		</li>
	<li><a href="#">Update member</a>
      <ul>
            <li><a href="admin.php">Add member</a></li>
            <li><a href="delform.php">Delete member</a></li>
          </ul>
		</li>
    <li><a href="logout.php">LogOut</a></li>
	</ul>
</nav>

</div>
</html>