<html>
<body style=" background-size: cover;" background="awardbg.jpg">
<center><img style="height:150px;" src="logo.png"></center><br>
<center><h1>PAPERS</h1></center>
</body>
</html>

<?php

function listFolderFiles($dir)
{
    echo '<ol>';
    foreach (new DirectoryIterator($dir) as $fileInfo) {
        if (!$fileInfo->isDot()) {
            echo '<li>' .'<font size = "5">'.'Empid:  '. $fileInfo->getFilename().'</font>'.'<br>';
			
            if ($fileInfo->isDir()) {
				$files = glob('paperconf/'.$fileInfo->getFilename().'/'.'*.*');
				$files2 = glob('paperjourn/'.$fileInfo->getFilename().'/'.'*.*');
				
				foreach($files as $file)    {
					echo "<a href='" . $file . "' target='_blank'>" . $file . "</a><br />";
				}
				foreach($files2 as $file)    {
					echo "<a href='" . $file . "' target='_blank'>" . $file . "</a><br />";
				}
                
            }
            echo '</li>';
        }
    }
    echo '</ol>';
}
//listFolderFiles('paperjourn');
listFolderFiles('paperconf');

?>
