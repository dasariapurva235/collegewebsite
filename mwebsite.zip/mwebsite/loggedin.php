<?php

session_start();
if(!isset($_SESSION['username'])){
header('location:login.php');
}


?>
<html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="styles6.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
<style>

</style>
</head>
<body>
<br>

<?php include "header.php" ?>
<div class="container">
  <br>
  <div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="loggedin.php">Home</a></li>
  </ul>
</div>
 <div class="sidebar col-md-3">

<h3> CSE</h3>
<ul>
<li><a href="#">Publications</a></li>
    <ul>
      <li><a href="#">Books</a></li>
      <li><a href="#">Journals</a></li>
 <li><a href="#">Consultancy Papers</a></li>
    </ul>
<li><a href="#">Projects</a></li>
    <ul>
      <li><a href="#">Research</a></li>
 <li><a href="#">Consultancy</a></li>
    </ul>
<li><a href="#">Workshops</a></li>
    <ul>
      <li><a href="#">Organized</a></li>
 <li><a href="#">Attended</a></li>
    </ul>
<li><a href="#">Recognitions</a></li>
    <ul>
      <li><a href="#">Certifications</a></li>
 <li><a href="#">Awards</a></li>
 <li><a href="#">Resource person</a></li>
 <li><a href="#">Special Chair</a></li>
    </ul>
<li><a href="#">Guest Lectures</a></li>

</div>
<div class=" content1 col-md-9">
<center>
<h2>Welcome <?php echo $_SESSION['username']; ?> </h2>
</center>
<div>
<div class="x">
<h4><a href="#">Update</a></h4>
</div>
</div>

<?php
$empid=$_SESSION['username'];
$conn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($conn,"final");
$sql="SELECT name, designation, qualifications, experience, areasofinterest, email,phone FROM profile WHERE empid ='$empid'";

$res = $conn->query($sql);
if ($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        
 
		echo nl2br  ("Name: " . $row["name"]. "\nDesignation: " . $row["designation"].
       "\nExperience: " . $row["experience"]."\nAreas of Interest: " . $row["areasofinterest"].
      "\nEmail Id: " . $row["email"]."\nPhone: " . $row["phone"]."<br>");
    

    }
} else {
    echo "0 results";
}

?>
</div>

 
</div>		
</body>
</html>
