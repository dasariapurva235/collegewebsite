<html>
<head>
<title>User login and Registration </title>
<link rel="stylesheet" type="text/css" href="fetch.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
</head>

<body>
<center>
<h1>Login</h1>
<div class="login">
  <form method="post" action="validation.php">
    <p><input type="text" name="username" id="username" value="" placeholder="Username or Email"></p>
    <p><input type="password" name="password" value="" placeholder="Password"></p>
   
    <p class="submit"><input type="submit" name="commit" value="Login"></p>
  </form>
</div>
</center>
</body>
</html>
