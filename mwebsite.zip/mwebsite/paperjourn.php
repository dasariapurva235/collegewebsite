<html>
 <head>
<link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  

 </head>
 <body>
  <?php include "header.php" ?>
  <div class="container">
  <br>
  <div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="loggedin.php">Home</a></li>
  <li><a href="#">Publications</a></li>
  <li><a href="paperjourn.php">Journals</a></li>
  <li>Update</li>
</ul>
</div>
 <div class="sidebar">

<h3> CSE</h3>
<ul>
<li><a href="#">Publications</a></li>
    <ul>
      <li><a href="#">Books</a></li>
      <li><a href="#">Journals</a></li>
 <li><a href="#">Consultancy Papers</a></li>
    </ul>
<li><a href="#">Projects</a></li>
    <ul>
      <li><a href="#">Research</a></li>
 <li><a href="#">Consultancy</a></li>
    </ul>
<li><a href="#">Workshops</a></li>
    <ul>
      <li><a href="#">Organized</a></li>
 <li><a href="#">Attended</a></li>
    </ul>
<li><a href="#">Recognitions</a></li>
    <ul>
      <li><a href="#">Certifications</a></li>
 <li><a href="#">Awards</a></li>
 <li><a href="#">Resource person</a></li>
 <li><a href="#">Special Chair</a></li>
    </ul>
<li><a href="#">Guest Lectures</a></li>

</div>	
<div class="content1">
  <form action="paperjournReg.php" method="post" enctype="multipart/form-data">
   Name of the Author:<br>
   <input type="text" name="author" id="author"><br>
   Publication Title of the Paper:<br>
   <input type:"text" name="publication_title" id="publication_title"><br>
   Volume number:<br>
   <input type="text" name="volume_no" id="volume_no"><br>
   Issue Number:<br>
   <input type="text" name="issue_no" id="issue_no"><br>
   ISSN:<br>
   <input type="text" name="issn" id="issn"><br>
   Impact Factor:<br>
   <input type="text" name="impact_factor" id="impact_factor"><br>
   Index:<br>
   <input type="text" name="index"><br>
   Month and Year of publication:<br>
   <input type="date" name="date" id="date"><br>
  Open Journal:<br>

    <input type="radio" name="openjournal" id="openjournal" value="yes" > Yes<br>

    <input type="radio" name="openjournal" id="openjournal" value="no"> No<br>

   UGC Approved Journal:<br>

   <input type="radio" name="ugcapproved" id="ugcapproved"value="yes" > Yes<br>

    <input type="radio" name="ugcapproved" id="ugcapproved" value="no"> No<br>

   Scopes Indexed:<br>

    <input type="radio" name="scopusindexed" id="scopusindexed" value="yes" > Yes<br>

    <input type="radio" name="scopusindexed" id="scopusindexed" value="no"> No<br>

   Web of Science:<br>

    <input type="radio" name="webofscience" id="webofscience" value="yes" > Yes<br>

    <input type="radio" name="webofscience" id="webofscience" value="no"> No<br>
	Number of Pages:<br>
	<input type:"text" name="pages"><br>
	PDF:<br>
	<input type="file" name="fileToUpload" id="fileToUpload"><br><br>
	<input type="submit" value="Submit"><br>
   </form>
   </div>
</div>  
 </body>
</html>