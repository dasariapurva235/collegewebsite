<?php

 

session_start();
header('location:paperjourn.html');


 

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username'];

$author= $_POST['author'];

$publication_title= $_POST['publication_title'];

$volume_no= $_POST['volume_no'];

$issue_no = $_POST['issue_no'];

$issn= $_POST['issn'];

$impact_factor= $_POST['impact_factor'];
$index=$_POST['index'];

$date=$_POST['month'];

$openjournal=$_POST['openjournal'];

$ugcapproved=$_POST['ugcapproved'];

$scopusindexed=$_POST['scopusindexed'];

$webofscience=$_POST['webofscience'];



 

 

$stmt = $dbh->prepare("insert into paperjourn values(?,?,?,?,?,?,?,?,?,?,?,?,?)");

$stmt->bindParam(1,$empid);

$stmt->bindParam(2,$author);

$stmt->bindParam(3,$publication_title);

$stmt->bindParam(4,$volume_no);

$stmt->bindParam(5,$issue_no);

$stmt->bindParam(6,$issn);

$stmt->bindParam(7,$impact_factor);
$stmt->bindParam(8,$index);
$stmt->bindParam(9,$date);

$stmt->bindParam(10,$openjournal);

$stmt->bindParam(11,$ugcapproved);

$stmt->bindParam(12,$scopusindexed);

$stmt->bindParam(13,$webofscience);


$stmt->execute();

$target_dir = "paperjourn/". $empid."/"; 													//this is because empid has the folder name
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    
if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
{
 echo "The file ". basename( $_FILES['file']['name']). " is uploaded";
 }
 else {
 echo "Problem uploading file";
 }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

if($stmt)
{
	header('location:paperjourn.html');
}
else
{
	echo "Failed";
}

 

?>