<?php

session_start();
header('location:admin.html');

$con = mysqli_connect("localhost","root","Apurva*23*");
mysqli_select_db($con,"final");

$name = $_POST['username'];
$pass = $_POST['password'];

$s = " select * from usertable where name = '$name'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if($num==1)
{
echo "User Name already taken";
}
else
{
	$apath = 'awards/'. $name;
	$pcpath = 'paperconf/'. $name;
	$pjpath = 'paperjourn/'.$name;
	$cpath= 'certifications/'.$name;
	$gpath='guestlectures/'.$name;
	mkdir($apath,0777,true);
	mkdir($pcpath,0777,true);
	mkdir($pjpath,0777,true);
	mkdir($cpath,0777,true);
	mkdir($gpath,0777,true);

	
$reg = " insert into usertable(EmpId,password) values ('$name','$pass') ";
mysqli_query($con,$reg);

echo "Registration Successful";
}



?>
