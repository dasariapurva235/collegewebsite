<?php

session_start(); 
header('location:research.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");






$empid=$_SESSION['username']; 
$fundingagency= $_POST['fundingagency'];
$principalinvestigator= $_POST['principalinvestigator'];
$title= $_POST['title'];
$regno=$_POST['regno'];
$cost= $_POST['cost'];
$status=$_POST['status'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];


$stmt = $dbh->prepare("insert into projects values(?,?,?,?,?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$fundingagency);
$stmt->bindParam(3,$principalinvestigator);
$stmt->bindParam(4,$title);
$stmt->bindParam(5,$regno);
$stmt->bindParam(6,$cost);
$stmt->bindParam(7,$status);
$stmt->bindParam(8,$startdate);
$stmt->bindParam(9,$enddate);
$stmt->execute();




//$reg = " insert into awards(awardname,date,place,awardedby,description,proof) VALUES ('$awardname','$year','$place','$awardedby','$desc','$proof') ";
  
//mysqli_query($conn,$reg);
echo "Success";

?>
