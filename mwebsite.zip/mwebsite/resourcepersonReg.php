<?php

session_start(); 
header('location:resourceperson.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username']; 
$topicname= $_POST['topicname'];
$date= $_POST['date'];
$venue = $_POST['venue'];
$description=$_POST['description'];


$stmt = $dbh->prepare("insert into resourceperson values(?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$topicname);
$stmt->bindParam(3,$date);
$stmt->bindParam(4,$venue);
$stmt->bindParam(5,$description);


$stmt->execute();

echo "Success";

?>
