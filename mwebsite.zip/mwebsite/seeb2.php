<?php
session_start();
?>
<html>
 <head>
<link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 </head>
 <body>
  <?php include "header2.php" ?>
  <div class="container">
  <br>
  <div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="loggedin.php">Home</a></li>
  <li><a href="#">Books</a></li>
  <li><a href="seeb2.php">Show</a></li>
</ul>
</div>
<div class="sidebar">

<h3> CSE</h3>
<ul>
<li><a href="#">Publications</a></li>
    <ul>
      <li><a href="#">Books</a></li>
      <li><a href="#">Journals</a></li>
 <li><a href="#">Consultancy Papers</a></li>
    </ul>
<li><a href="#">Projects</a></li>
    <ul>
      <li><a href="#">Research</a></li>
 <li><a href="#">Consultancy</a></li>
    </ul>
<li><a href="#">Workshops</a></li>
    <ul>
      <li><a href="#">Organized</a></li>
 <li><a href="#">Attended</a></li>
    </ul>
<li><a href="#">Recognitions</a></li>
    <ul>
      <li><a href="#">Certifications</a></li>
 <li><a href="#">Awards</a></li>
 <li><a href="#">Resource person</a></li>
 <li><a href="#">Special Chair</a></li>
    </ul>
<li><a href="#">Guest Lectures</a></li>

</div>	     			 
<div class="content1">
<?php
$empid=$_SESSION['username'];
$conn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($conn,"final");
$sql="SELECT empid,title,publishername FROM books";

$res = $conn->query($sql);
if ($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        
 
		echo nl2br  ("Empid: " . $row["empid"]. "\nTitle: " . $row["title"].
       "\nPublisher Name: " . $row["publishername"]."<br>");
    

    }
} else {
    echo "0 results";
}

?>
</div>
</body>
</html>