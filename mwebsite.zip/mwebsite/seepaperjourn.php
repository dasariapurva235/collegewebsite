<?php
session_start(); 
header('location:paperjourn.html');
$empid=$_SESSION['username'];
$directory = "uploads/paperjourn/".$empid;		// Here get the userid 17251A05F6 using session variables same as empid in awardReg.php

$dir = opendir($directory); 
echo '<ul>';
while ($read = readdir($dir)) 
{

if ($read!='.' && $read!='..') 
{ 
echo '<li><a href= '.$directory.$read.'">'.$read.'</a></li>'; 
}

}

echo '</ul>';

closedir($dir); 
?>