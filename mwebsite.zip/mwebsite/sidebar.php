<!DOCTYPE html>
<head>
 <link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
<body>
<?php include "header.php" ?>

<div class="container">


<div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li><a href="#">CSE</a></li>
  <li><a href="#">Recognition</a></li>
  <li>Special Chair</li>
</ul>
</div>
<div class="sidebar">

<h3> CSE</h3>
<ul>
<li><a href="guestlectures.html">Guest Lectures</a></li>
<li><a href="#">Presentations</a></li>
<li><a href="workshop.html">Workshops</a></li>
<li><a href="#">Consultancy</a></li>

</div>
<div class="content1">
<h1>Content</h1>
<p>jsagduyefgbqekqndlqwertyuiolkjhgfzxcvbnmnbczasdfghjklpiuyrewasdfghjyuiolknsdcghnrewsxiuytrewqasdfghjkmnbvzawedcvbyujmkoihgfcvghderthjksfgvbniuytresdfhbnmiufd </p>
</div>
</div>
</html>