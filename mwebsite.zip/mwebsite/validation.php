<?php

session_start();


$con = mysqli_connect("localhost","root","");
mysqli_select_db($con,"final");

$name = $_POST['username'];
$pass = $_POST['password'];




$s = " select * from usertable where empid = '$name' && password = '$pass'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);



if($num==1)
{
	
	if($name=='admincse'){
		$_SESSION['username']=$name;
		header('location:loggedin2.php');
	}
	else
	{
      $_SESSION['username'] = $name;
      header('location:loggedin.php');
	}
}
else
{
	//header('location:login.php');
	//echo "Unsuccessful login";
	echo '<script language="javascript">';
	echo 'alert("Invalid username or password");';
	echo 'window.location="login.php"';
	echo '</script>';
}



?>

