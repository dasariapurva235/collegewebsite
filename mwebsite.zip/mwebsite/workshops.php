<html>
 <head>
<link rel="stylesheet" type="text/css" href="ss1.css">
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  

 </head>
 <body>
  <?php include "header.php" ?>
  <div class="container">
  <br>
  <div class="breadcrumbs">
<ul class="breadcrumb">
  <li><a href="loggedin.php">Home</a></li>
  <li><a href="#">Workshops</a></li>
  <li><a href="#">Attended</a></li>
  <li><a href="workshops.php">Update</a></li>
</ul>
</div>
 <div class="sidebar">

<h3> CSE</h3>
<ul>
<li><a href="#">Publications</a></li>
    <ul>
      <li><a href="#">Books</a></li>
      <li><a href="#">Journals</a></li>
 <li><a href="#">Consultancy Papers</a></li>
    </ul>
<li><a href="#">Projects</a></li>
    <ul>
      <li><a href="#">Research</a></li>
 <li><a href="#">Consultancy</a></li>
    </ul>
<li><a href="#">Workshops</a></li>
    <ul>
      <li><a href="#">Organized</a></li>
 <li><a href="#">Attended</a></li>
    </ul>
<li><a href="#">Recognitions</a></li>
    <ul>
      <li><a href="#">Certifications</a></li>
 <li><a href="#">Awards</a></li>
 <li><a href="#">Resource person</a></li>
 <li><a href="#">Special Chair</a></li>
    </ul>
<li><a href="#">Guest Lectures</a></li>

</div>	q
<div class="content1">
  <form action="workshopsReg.php" enctype="multipart/form-data" method="post">
   Title of the program:<br>
   <input type="text" name="programtitle" id="programtitle"><br>
   Description:<br>
   <input type="text" name="description" id="description"><br>
   Start Date:<br>
   <input type="date" name="startdate" id="startdate"><br>
   End Date:<br>
   <input type="date" name="enddate" id="enddate"><br>
   Venue:<br>
   <input type="text" name="venue"><br>
   Resource person:<br>
   <input type="text" name="resourceperson" id="resourceperson"><br>
   Type of Training:<br>
   <input type="text" name="type" id="type"><br>
   Training Methodology:<br>
   <input type="text" name="trainingmethodology" id="trainingmethodology"><br>
   Name of the participant:<br>
   <input type="text" name="participants" id="participants"><br>
   Total number of participants:<br>
   <input type="text" name="noofparticipants" id="noofparticipants"><br><br>
   <input type="submit" value="Submit"><br>
   
   </form>
   </div>
 </body>
</html>