<?php

session_start(); 
header('location:workshops.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username']; 
$programtitle= $_POST['programtitle'];
$description=$_POST['description'];
$startdate= $_POST['startdate'];
$enddate= $_POST['enddate'];
$venue = $_POST['venue'];
$resourceperson= $_POST['resourceperson'];
$type = $_POST['type'];
$trainingmethodology=$_POST['trainingmethodology'];
$participants=$_POST['participants'];
$noofparticipants=$_POST['noofparticipants'];

$stmt = $dbh->prepare("insert into workshops values(?,?,?,?,?,?,?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$programtitle);
$stmt->bindParam(3,$description);
$stmt->bindParam(4,$startdate);
$stmt->bindParam(5,$enddate);
$stmt->bindParam(6,$venue);
$stmt->bindParam(7,$resourceperson);
$stmt->bindParam(8,$type);
$stmt->bindParam(9,$trainingmethodology);
$stmt->bindParam(10,$participants);
$stmt->bindParam(11,$noofparticipants);
$stmt->execute();

echo "Success";

?>
