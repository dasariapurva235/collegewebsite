<?php

session_start(); 
header('location:workshopsorganised.html');

$dbh = new PDO("mysql:host=localhost;dbname=final", "root", "");

$empid=$_SESSION['username']; 
$programtitle= $_POST['programtitle'];
$venue = $_POST['venue'];
$startdate= $_POST['startdate'];
$enddate= $_POST['enddate'];
$role=$_POST['role'];

$stmt = $dbh->prepare("insert into workshopsorganised values(?,?,?,?,?,?)");
$stmt->bindParam(1,$empid);
$stmt->bindParam(2,$programtitle);
$stmt->bindParam(3,$venue);
$stmt->bindParam(4,$startdate);
$stmt->bindParam(5,$enddate);
$stmt->bindParam(6,$role);

$stmt->execute();

echo "Success";

?>
